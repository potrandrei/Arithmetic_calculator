package com.company;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int fnum, snum, tnum, total;                                         //Initiate the parameters for calculations.
	    Scanner andre = new Scanner(System.in);                              //Create the andre objekt.

        System.out.println("Enter the first number : ");                     // iInput the first number.
        fnum = andre.nextInt();
        System.out.println("Enter the second number : ");                    // Input the second number.
        snum = andre.nextInt();
        System.out.println("Enter the third number : ");                     // Input the third number.
        tnum = andre.nextInt();

        total = fnum+snum+tnum;
        System.out.println("The total sum of all 3 numbers is = " + total); // The total sum.
    }
}
